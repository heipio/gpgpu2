import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "compiler"))

from aec_assembler import Assembler


def test_vector_add_exact_hex():
    asm = (ROOT / "tests" / "vector_add.asm").read_text()
    encoded = [inst.to_hex() for inst in Assembler().assemble_text(asm)]
    assert encoded == [
        "00100320000100000000400000000102",
        "00100320000200000000400400000102",
        "00100320000300000000400800000102",
        "00100120000400010000000000000002",
        "00100120000500020000000000000002",
        "00020020000600040000000500000001",
        "00110120000000030000000000060002",
        "007f0020000000000000000000000000",
    ]


def test_labels_and_predicate_encode():
    encoded = [inst.to_hex() for inst in Assembler().assemble_text("""
start:
  @P1 BRX P1, done
  BR start
done:
  HALT
""")]
    assert encoded[0] == "00218021000000000000000200000000"
    assert encoded[1] == "00200020000000000000000000000000"
    assert encoded[2] == "007f0020000000000000000000000000"


def test_b64_alignment_rejected():
    try:
        Assembler().assemble_text("LD.gmem.u64 R1, [R0 + 0]")
    except ValueError as exc:
        assert "even-aligned" in str(exc)
    else:
        raise AssertionError("expected b64 odd-register diagnostic")


def test_setp_and_predicated_instruction_encode():
    encoded = [inst.to_hex() for inst in Assembler().assemble_text("""
      CPY.u32 R1, %laneid
      LOADI.u32 R2, 4
      SETP.lt.u32 P0, R1, R2
      @P0 ADD.u32 R3, R1, R2
      @!P0 ST.gmem.u32 [R10 + 0], R3
    """)]
    assert encoded[2] == "00080020000000010000000200000002"
    assert encoded[3].startswith("00028020")
    assert encoded[4].startswith("00118128")
