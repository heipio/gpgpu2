`ifndef AEC_PKG_SV
`define AEC_PKG_SV
`timescale 1ns/1ps

package aec_pkg;
  parameter int LOGICAL_WARP_WIDTH = 32;
  parameter int PHYSICAL_SIMD_LANES = 8;
  parameter int ISSUE_BEATS        = 4;

  parameter int INSTR_WIDTH_BITS = 128;
  parameter int REG_INDEX_BITS   = 8;
  parameter int PRED_INDEX_BITS  = 3;

  parameter logic [15:0] AEC_CSR_CTRL_ADDR       = 16'h0000;
  parameter logic [15:0] AEC_CSR_PC_ADDR         = 16'h0004;
  parameter logic [15:0] AEC_CSR_STATUS_ADDR     = 16'h0008;
  parameter logic [15:0] AEC_CSR_FAULT_CODE_ADDR = 16'h000c;
  parameter logic [15:0] AEC_CSR_FAULT_PC_ADDR   = 16'h0010;
  parameter logic [15:0] AEC_IMEM_BASE_ADDR      = 16'h1000;
  parameter logic [15:0] AEC_IMEM_LAST_ADDR      = 16'h1fff;

  typedef enum logic [15:0] {
    AEC_OP_NOP        = 16'h0000,
    AEC_OP_MOV        = 16'h0001,
    AEC_OP_IADD_U32   = 16'h0002,
    AEC_OP_IMUL_U32   = 16'h0003,
    AEC_OP_FADD_F32   = 16'h0004,
    AEC_OP_FMUL_F32   = 16'h0005,
    AEC_OP_MAD_F32    = 16'h0006,
    AEC_OP_FMA_F32    = 16'h0007,
    AEC_OP_SETP       = 16'h0008,
    AEC_OP_CMPP       = 16'h0009,
    AEC_OP_SUB_U32    = 16'h000a,
    AEC_OP_AND_B32    = 16'h000b,
    AEC_OP_OR_B32     = 16'h000c,
    AEC_OP_XOR_B32    = 16'h000d,
    AEC_OP_SHL_B32    = 16'h000e,
    AEC_OP_SHR_B32    = 16'h000f,
    AEC_OP_LD         = 16'h0010,
    AEC_OP_ST         = 16'h0011,
    AEC_OP_FENCE      = 16'h0012,
    AEC_OP_BRA        = 16'h0020,
    AEC_OP_BRX        = 16'h0021,
    AEC_OP_SSY        = 16'h0022,
    AEC_OP_SYNC       = 16'h0023,
    AEC_OP_BAR_SYNC   = 16'h0024,
    AEC_OP_SHFL       = 16'h0030,
    AEC_OP_REDUCE_ADD = 16'h0031,
    AEC_OP_SFU_RCP    = 16'h0040,
    AEC_OP_SFU_EXP2   = 16'h0041,
    AEC_OP_MMA_E4M3   = 16'h0050,
    AEC_OP_HALT       = 16'h007f
  } aec_opcode_e;

  typedef enum logic [3:0] {
    AEC_FAULT_NONE                = 4'd0,
    AEC_FAULT_ILLEGAL_INSTRUCTION = 4'd1,
    AEC_FAULT_MISALIGNED_ACCESS   = 4'd2,
    AEC_FAULT_ADDRESS_ERROR       = 4'd3,
    AEC_FAULT_SIMT_STACK_FAULT    = 4'd4,
    AEC_FAULT_BARRIER_DEADLOCK    = 4'd5,
    AEC_FAULT_WATCHDOG_TIMEOUT    = 4'd6,
    AEC_FAULT_UNSUPPORTED_FEATURE = 4'd7
  } aec_fault_e;

endpackage

`endif
